import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createApp } from '../src/app.js';

let server, base;
before(async () => {
  server = createApp().listen(0, '127.0.0.1');
  await once(server, 'listening');
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => new Promise(resolve => server.close(resolve)));

test('health clearly reports sample mode and no database', async () => {
  const response = await fetch(`${base}/api/health`);
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { status: 'ok', data_source: 'sample', database_connected: false });
});
test('student response preserves frontend field names and missing students return 404', async () => {
  const response = await fetch(`${base}/api/students/0000000000`);
  const body = await response.json();
  assert.equal(body.data_source, 'sample');
  assert.equal(body.data.student_id, '0000000000');
  assert.equal(typeof body.data.major_progress, 'number');
  assert.equal((await fetch(`${base}/api/students/missing`)).status, 404);
});
test('course search filters and rejects repeated query parameters', async () => {
  const response = await fetch(`${base}/api/courses?q=data`);
  assert.deepEqual((await response.json()).data.map(c => c.id), ['DEMO-201']);
  assert.equal((await fetch(`${base}/api/courses?q=a&q=b`)).status, 400);
  assert.equal((await fetch(`${base}/api/courses/missing`)).status, 404);
  assert.equal((await fetch(`${base}/api/courses/DEMO-101`)).status, 200);
});
test('serves frontend without exposing backend files', async () => {
  assert.match(await (await fetch(base)).text(), /Main.js/);
  for (const path of ['/api/unknown', '/.env', '/package.json', '/src/server.js']) {
    assert.equal((await fetch(`${base}${path}`)).status, 404);
  }
});
