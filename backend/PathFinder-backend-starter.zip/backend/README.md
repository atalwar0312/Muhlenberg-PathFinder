# PathFinder backend starter

Node.js + Express, using explicitly labeled sample data until PostgreSQL is ready.
Prepared with ChatGPT/Codex assistance; review and record usage as required by your class.

## Run locally

Use Node.js 22 or newer. From the repository root:

```sh
cd backend
npm ci
npm start
```

Open http://127.0.0.1:3000 for the existing frontend or
http://127.0.0.1:3000/api/health to check the server.
The frontend still uses its original hardcoded data; serving it does not connect it to the API.
Use `npm run dev` for automatic restart and `npm test` for API checks.
Optionally copy `.env.example` to `.env` to change the port. Never commit credentials.

## API contract

All data endpoints return `{ "data_source": "sample", "data": ... }`.
Errors return `{ "error": "message" }` with an appropriate HTTP status.

| Method | Path | Result |
| --- | --- | --- |
| GET | `/api/health` | Server status and explicit database connection status |
| GET | `/api/students/0000000000` | Demo student profile and fixture progress |
| GET | `/api/courses` | Two invented demonstration courses |
| GET | `/api/courses?q=data` | Case-insensitive title/ID search |
| GET | `/api/courses/DEMO-101` | One demonstration course |

Unknown IDs and routes return 404. Repeated `q` or a query over 200 characters returns 400.
Progress numbers are fixtures, not calculated degree audits. The catalog CSV has not been imported.

## Frontend integration example

When the frontend is served by this Express server, use a relative URL:

```js
const response = await fetch('/api/students/0000000000');
if (!response.ok) throw new Error('Unable to load student');
const { data: student } = await response.json();
// Use student to build the dashboard, and show a sample-data label.
```

A frontend running on another port needs an agreed development proxy or restricted CORS configuration.

## Connect PostgreSQL later

Ask Hudson for the SQL schema/migrations, seed data, and local setup instructions.
Agree on student IDs, course IDs, completed courses, and requirement relationships first.
Implement a PostgreSQL repository exposing the three async methods in `src/data/sample.js`:
`getStudent(id)`, `listCourses(query)`, and `getCourse(id)`.
Use parameterized SQL and `DATABASE_URL` from the environment. Do not guess table names.
Pass the new repository to `createApp`, update data-source/health reporting, and add database tests.
The commented DATABASE_URL is only a placeholder; no PostgreSQL connection exists yet.

## Scope

Local read-only development scaffold. No login, writes, real student records, degree-rule engine,
or chatbot integration is implemented. Add authentication and student/advisor authorization
before using real academic records or exposing the service publicly.

## Files

- `src/server.js`: environment configuration and listening server.
- `src/app.js`: HTTP routes, static frontend serving, and error handling.
- `src/data/sample.js`: sample records and replaceable data access methods.
- `test/api.test.js`: HTTP integration checks.
