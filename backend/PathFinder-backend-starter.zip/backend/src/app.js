import express from 'express';
import { fileURLToPath } from 'node:url';
import { sampleRepository } from './data/sample.js';

export function createApp(repository = sampleRepository) {
  const app = express();
  app.disable('x-powered-by');
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', data_source: 'sample', database_connected: false });
  });
  app.get('/api/students/:id', async (req, res) => {
    const student = await repository.getStudent(req.params.id);
    if (!student) return res.status(404).json({ error: 'Student not found' });
    res.json({ data_source: 'sample', data: student });
  });
  app.get('/api/courses', async (req, res) => {
    const q = req.query.q ?? '';
    if (typeof q !== 'string' || q.length > 200) {
      return res.status(400).json({ error: 'q must be a single string of at most 200 characters' });
    }
    res.json({ data_source: 'sample', data: await repository.listCourses(q) });
  });
  app.get('/api/courses/:id', async (req, res) => {
    const course = await repository.getCourse(req.params.id);
    if (!course) return res.status(404).json({ error: 'Course not found' });
    res.json({ data_source: 'sample', data: course });
  });
  // Serve only the frontend directory, never the repository or environment files.
  app.use(express.static(fileURLToPath(new URL('../../frontend/', import.meta.url))));
  app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
  app.use((err, req, res, next) => {
    console.error('Request failed:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  });
  return app;
}
